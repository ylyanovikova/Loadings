import styled from 'styled-components';

const Container = styled.div`
  /* padding: 10px; */
  background: #333333;
  /* position: relative; */
  width: 100vw;
  height: 100vh;
  /* margin: 100px auto; */
`;

export default Container;
